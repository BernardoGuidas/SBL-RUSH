import { useState } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface TowersGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

type Cell = 'hidden' | 'bomb' | 'gem' | 'revealed-bomb' | 'revealed-gem';

export default function TowersGame({ onClose }: TowersGameProps) {
  const [betAmount, setBetAmount] = useState(10);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [gameActive, setGameActive] = useState(false);
  const [towers, setTowers] = useState<Cell[][]>([[], [], []]);
  const [revealed, setRevealed] = useState<boolean[][]>([[], [], []]);
  const [multiplier, setMultiplier] = useState(1.0);
  const [gemsFound, setGemsFound] = useState(0);
  const [balance, setBalance] = useState(1000);
  const [message, setMessage] = useState('');
  const [gameHistory, setGameHistory] = useState<number[]>([]);

  const difficultySettings = {
    easy: { height: 5, bombs: 1 },
    medium: { height: 8, bombs: 2 },
    hard: { height: 12, bombs: 3 },
  };

  const startGame = () => {
    const settings = difficultySettings[difficulty];
    const newTowers: Cell[][] = [];
    const newRevealed: boolean[][] = [];

    for (let tower = 0; tower < 3; tower++) {
      const towerCells: Cell[] = [];
      const towerRevealed: boolean[] = [];

      for (let i = 0; i < settings.height; i++) {
        towerCells.push('hidden');
        towerRevealed.push(false);
      }

      // Place bombs randomly
      const bombPositions = new Set<number>();
      while (bombPositions.size < settings.bombs) {
        bombPositions.add(Math.floor(Math.random() * settings.height));
      }

      bombPositions.forEach((pos) => {
        towerCells[pos] = 'bomb';
      });

      // Rest are gems
      for (let i = 0; i < settings.height; i++) {
        if (towerCells[i] === 'hidden') {
          towerCells[i] = 'gem';
        }
      }

      newTowers.push(towerCells);
      newRevealed.push(towerRevealed);
    }

    setTowers(newTowers);
    setRevealed(newRevealed);
    setGameActive(true);
    setGemsFound(0);
    setMultiplier(1.0);
    setMessage('');
  };

  const revealCell = (towerIndex: number, cellIndex: number) => {
    if (!gameActive || revealed[towerIndex][cellIndex]) return;

    const newRevealed = revealed.map((r) => [...r]);
    newRevealed[towerIndex][cellIndex] = true;
    setRevealed(newRevealed);

    const cell = towers[towerIndex][cellIndex];

    if (cell === 'bomb') {
      setGameActive(false);
      setMessage('💥 Você acertou uma bomba! Jogo terminado.');
      setBalance(balance - betAmount);
      setGameHistory([...gameHistory, 0]);
      return;
    }

    // Found a gem
    const newGemsFound = gemsFound + 1;
    setGemsFound(newGemsFound);

    const newMultiplier = 1.0 + newGemsFound * 0.25;
    setMultiplier(newMultiplier);
  };

  const cashout = () => {
    const winAmount = betAmount * multiplier;
    setBalance(balance + winAmount);
    setMessage(`✅ Você sacou R$ ${winAmount.toFixed(2)}!`);
    setGameHistory([...gameHistory, winAmount]);
    setGameActive(false);
  };

  const resetGame = () => {
    setTowers([[], [], []]);
    setRevealed([[], [], []]);
    setGameActive(false);
    setGemsFound(0);
    setMultiplier(1.0);
    setMessage('');
  };

  const settings = difficultySettings[difficulty];

  return (
    <div className="space-y-6">
      {/* Game Board */}
      <div className="bg-gradient-to-b from-[#1E2847] to-[#151B35] rounded-lg p-6 border border-[#2A3A52]">
        <div className="grid grid-cols-3 gap-4">
          {towers.map((tower, towerIndex) => (
            <div key={towerIndex} className="space-y-2">
              <h3 className="text-center text-sm font-semibold text-[#D4AF37]">Torre {towerIndex + 1}</h3>
              <div className="space-y-1 max-h-96 overflow-y-auto">
                {tower.map((cell, cellIndex) => (
                  <button
                    key={`${towerIndex}-${cellIndex}`}
                    onClick={() => revealCell(towerIndex, cellIndex)}
                    disabled={!gameActive || revealed[towerIndex][cellIndex]}
                    className={`w-full py-2 rounded-lg font-semibold transition-all text-sm ${
                      !revealed[towerIndex][cellIndex]
                        ? 'bg-gradient-to-br from-[#2A3A52] to-[#1E2847] hover:from-[#3A4A62] border border-[#3A4A62] cursor-pointer'
                        : cell === 'gem'
                          ? 'bg-gradient-to-br from-[#10b981] to-[#059669] border border-[#34d399] text-white'
                          : 'bg-gradient-to-br from-[#dc2626] to-[#991b1b] border border-[#ef4444] text-white'
                    }`}
                  >
                    {revealed[towerIndex][cellIndex] ? (cell === 'gem' ? '💎' : '💣') : '?'}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-[#2A3A52]">
          <div className="text-center">
            <p className="text-gray-400 text-sm">Gemas Encontradas</p>
            <p className="text-2xl font-bold text-[#D4AF37]">{gemsFound}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm">Multiplicador</p>
            <p className="text-2xl font-bold text-[#D4AF37]">{multiplier.toFixed(2)}x</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm">Ganho Potencial</p>
            <p className="text-2xl font-bold text-[#D4AF37]">R$ {(betAmount * multiplier).toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Result Display */}
      {message && (
        <div className="text-center">
          <p className={`text-lg font-semibold ${message.includes('✅') ? 'text-green-400' : 'text-red-400'}`}>
            {message}
          </p>
        </div>
      )}

      {/* Difficulty Selection */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-3">Dificuldade</label>
        <div className="grid grid-cols-3 gap-3">
          {(['easy', 'medium', 'hard'] as const).map((level) => (
            <button
              key={level}
              onClick={() => setDifficulty(level)}
              disabled={gameActive}
              className={`py-2 rounded-lg font-semibold transition-all ${
                difficulty === level
                  ? 'bg-[#D4AF37] text-black'
                  : 'bg-[#1E2847] text-gray-300 hover:bg-[#2A3A52]'
              }`}
            >
              {level === 'easy' ? '⭐' : level === 'medium' ? '⭐⭐' : '⭐⭐⭐'}
              <br />
              {level.charAt(0).toUpperCase() + level.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={gameActive}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={gameActive}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        {!gameActive ? (
          <button
            onClick={startGame}
            className="btn-premium flex items-center justify-center space-x-2 col-span-2"
          >
            <Play className="w-5 h-5" />
            <span>Iniciar Jogo</span>
          </button>
        ) : (
          <button
            onClick={cashout}
            className="btn-premium flex items-center justify-center space-x-2 col-span-2"
          >
            <span>Sacar R$ {(betAmount * multiplier).toFixed(2)}</span>
          </button>
        )}
        <button
          onClick={resetGame}
          className="col-span-2 px-4 py-3 rounded-lg font-semibold border border-[#2A3A52] text-gray-300 hover:bg-[#1E2847] transition-colors"
        >
          <RotateCcw className="w-5 h-5 inline mr-2" />
          Reiniciar
        </button>
      </div>

      {/* Last Results */}
      {gameHistory.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Últimos Ganhos</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {gameHistory.slice(-5).map((result, i) => (
              <div
                key={i}
                className="flex-shrink-0 px-3 py-2 bg-[#1E2847] rounded-lg border border-[#2A3A52] text-center"
              >
                <p className={`font-bold ${result > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {result > 0 ? '+' : ''} R$ {result.toFixed(2)}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Balance Info */}
      <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
        <p className="text-sm text-gray-300">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>
    </div>
  );
}
