import { useState, useEffect } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { getLoginUrl } from '@/const';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import GamesSection from '@/components/GamesSection';
import Modal from '@/components/Modal';
import LoginModal from '@/components/LoginModal';
import CrashGame from '@/components/CrashGame';
import MinesGame from '@/components/MinesGame';
import DoubleGame from '@/components/DoubleGame';
import DiceGame from '@/components/DiceGame';
import PlinkoGame from '@/components/PlinkoGame';
import TowersGame from '@/components/TowersGame';

export default function Home() {
  const { user, loading, logout } = useAuth();
  const [balance, setBalance] = useState(0);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [withdrawModalOpen, setWithdrawModalOpen] = useState(false);
  const [crashGameOpen, setCrashGameOpen] = useState(false);
  const [minesGameOpen, setMinesGameOpen] = useState(false);
  const [doubleGameOpen, setDoubleGameOpen] = useState(false);
  const [diceGameOpen, setDiceGameOpen] = useState(false);
  const [plinkoGameOpen, setPlinkoGameOpen] = useState(false);
  const [towersGameOpen, setTowersGameOpen] = useState(false);

  // Load user balance from database
  useEffect(() => {
    if (user) {
      setBalance(parseFloat(user.balance || '100.00'));
    }
  }, [user]);

  const handleLogout = async () => {
    await logout();
  };

  const handleDeposit = (amount: number) => {
    const newBalance = balance + amount;
    setBalance(newBalance);
    setDepositModalOpen(false);
  };

  const handleWithdraw = (amount: number) => {
    if (amount <= balance) {
      const newBalance = balance - amount;
      setBalance(newBalance);
      setWithdrawModalOpen(false);
    }
  };

  const updateBalance = (newBalance: number) => {
    setBalance(newBalance);
  };

  if (loading) {
    return <div className="min-h-screen bg-[#0A0E27] flex items-center justify-center">Loading...</div>;
  }

  const isLoggedIn = !!user;

  return (
    <div className="min-h-screen bg-[#0A0E27]">
      {/* Header */}
      <Header
        balance={balance}
        isLoggedIn={isLoggedIn}
        onDeposit={() => setDepositModalOpen(true)}
        onWithdraw={() => setWithdrawModalOpen(true)}
        onLogin={() => setLoginModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="pt-20">
        {/* Hero Section */}
        <HeroSection
          onGetStarted={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              document.getElementById('games')?.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          onLearnMore={() => {
            // TODO: Scroll to tutorial or info section
          }}
        />

        {/* Games Section */}
        <GamesSection
          onPlayCrash={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setCrashGameOpen(true);
            }
          }}
          onPlayMines={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setMinesGameOpen(true);
            }
          }}
          onPlayDouble={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setDoubleGameOpen(true);
            }
          }}
          onPlayDice={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setDiceGameOpen(true);
            }
          }}
          onPlayPlinko={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setPlinkoGameOpen(true);
            }
          }}
          onPlayTowers={() => {
            if (!isLoggedIn) {
              setLoginModalOpen(true);
            } else {
              setTowersGameOpen(true);
            }
          }}
        />

        {/* Footer */}
        <footer className="bg-[#0F1B35] border-t border-[#2A3A52] py-12 px-4">
          <div className="container mx-auto">
            <div className="grid md:grid-cols-4 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-bold text-white mb-4">SBLRush</h3>
                <p className="text-gray-400 text-sm">Plataforma premium de apostas online com os melhores mini-jogos.</p>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Jogos</h4>
                <ul className="space-y-2 text-gray-400 text-sm">
                  <li><a href="#" className="hover:text-[#D4AF37]">Crash</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Mines</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Double</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Suporte</h4>
                <ul className="space-y-2 text-gray-400 text-sm">
                  <li><a href="#" className="hover:text-[#D4AF37]">FAQ</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Contato</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Termos</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Legal</h4>
                <ul className="space-y-2 text-gray-400 text-sm">
                  <li><a href="#" className="hover:text-[#D4AF37]">Privacidade</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Termos de Uso</a></li>
                  <li><a href="#" className="hover:text-[#D4AF37]">Responsável</a></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-[#2A3A52] pt-8 text-center text-gray-400 text-sm">
              <p>&copy; 2026 SBLRush. Todos os direitos reservados. Jogue com responsabilidade.</p>
            </div>
          </div>
        </footer>
      </main>

      {/* Modals */}
      <LoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        onLogin={() => setLoginModalOpen(false)}
      />

      <Modal
        isOpen={depositModalOpen}
        onClose={() => setDepositModalOpen(false)}
        title="Depositar Fundos"
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-300 mb-2">Valor</label>
            <input
              type="number"
              placeholder="100.00"
              id="deposit-amount"
              className="w-full bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-300 mb-2">Método de Pagamento</label>
            <select className="w-full bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]">
              <option>PIX</option>
              <option>Cartão de Crédito</option>
              <option>Transferência Bancária</option>
            </select>
          </div>
          <button
            onClick={() => {
              const amount = parseFloat((document.getElementById('deposit-amount') as HTMLInputElement)?.value || '100');
              handleDeposit(amount);
            }}
            className="w-full btn-premium"
          >
            Depositar
          </button>
        </div>
      </Modal>

      <Modal
        isOpen={withdrawModalOpen}
        onClose={() => setWithdrawModalOpen(false)}
        title="Sacar Fundos"
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-300 mb-2">Valor (Máximo: R$ {balance.toFixed(2)})</label>
            <input
              type="number"
              placeholder="100.00"
              id="withdraw-amount"
              max={balance}
              className="w-full bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-300 mb-2">Método de Saque</label>
            <select className="w-full bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]">
              <option>PIX</option>
              <option>Transferência Bancária</option>
              <option>Criptomoeda</option>
            </select>
          </div>
          <button
            onClick={() => {
              const amount = parseFloat((document.getElementById('withdraw-amount') as HTMLInputElement)?.value || '100');
              handleWithdraw(amount);
            }}
            className="w-full btn-premium"
          >
            Sacar
          </button>
        </div>
      </Modal>

      <Modal
        isOpen={crashGameOpen}
        onClose={() => setCrashGameOpen(false)}
        title="🚀 Crash"
        size="lg"
      >
        <CrashGame onClose={() => setCrashGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>

      <Modal
        isOpen={minesGameOpen}
        onClose={() => setMinesGameOpen(false)}
        title="💎 Mines"
        size="lg"
      >
        <MinesGame onClose={() => setMinesGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>

      <Modal
        isOpen={doubleGameOpen}
        onClose={() => setDoubleGameOpen(false)}
        title="🎰 Double"
        size="lg"
      >
        <DoubleGame onClose={() => setDoubleGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>

      <Modal
        isOpen={diceGameOpen}
        onClose={() => setDiceGameOpen(false)}
        title="🎲 Dice"
        size="lg"
      >
        <DiceGame onClose={() => setDiceGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>

      <Modal
        isOpen={plinkoGameOpen}
        onClose={() => setPlinkoGameOpen(false)}
        title="⚪ Plinko"
        size="lg"
      >
        <PlinkoGame onClose={() => setPlinkoGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>

      <Modal
        isOpen={towersGameOpen}
        onClose={() => setTowersGameOpen(false)}
        title="🏰 Torres"
        size="lg"
      >
        <TowersGame onClose={() => setTowersGameOpen(false)} onBalanceUpdate={updateBalance} currentBalance={balance} />
      </Modal>
    </div>
  );
}
