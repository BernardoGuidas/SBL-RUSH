import { useState, useEffect } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface DoubleGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

export default function DoubleGame({ onClose }: DoubleGameProps) {
  const [betAmount, setBetAmount] = useState(10);
  const [selectedColor, setSelectedColor] = useState<'red' | 'black' | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<'red' | 'black' | null>(null);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [gameHistory, setGameHistory] = useState<('red' | 'black')[]>(['red', 'black', 'red', 'black', 'red']);
  const [balance, setBalance] = useState(1000);
  const [message, setMessage] = useState('');

  const spinWheel = () => {
    if (!selectedColor || isSpinning) return;

    setIsSpinning(true);
    setMessage('');
    setResult(null);

    // Random result
    const isRed = Math.random() > 0.5;
    const resultColor = isRed ? 'red' : 'black';

    // Calculate rotation (red = 0-180, black = 180-360)
    const randomRotation = isRed 
      ? Math.random() * 180 
      : 180 + Math.random() * 180;

    // Spin animation
    const finalRotation = wheelRotation + 360 * 3 + randomRotation;
    setWheelRotation(finalRotation);

    setTimeout(() => {
      setResult(resultColor);
      setIsSpinning(false);

      if (selectedColor === resultColor) {
        const winAmount = betAmount * 2;
        setBalance(balance + betAmount);
        setMessage(`✅ Você ganhou R$ ${winAmount.toFixed(2)}!`);
      } else {
        setBalance(balance - betAmount);
        setMessage(`❌ Você perdeu R$ ${betAmount.toFixed(2)}`);
      }

      setGameHistory([resultColor, ...gameHistory.slice(0, 4)]);
    }, 3000);
  };

  const resetGame = () => {
    setSelectedColor(null);
    setResult(null);
    setMessage('');
  };

  return (
    <div className="space-y-6">
      {/* Wheel */}
      <div className="flex justify-center py-8">
        <div className="relative w-64 h-64">
          {/* Pointer */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2 z-10">
            <div className="w-0 h-0 border-l-6 border-r-6 border-t-8 border-l-transparent border-r-transparent border-t-[#D4AF37]"></div>
          </div>

          {/* Wheel */}
          <div
            className="w-full h-full rounded-full border-8 border-[#D4AF37] flex items-center justify-center transition-transform duration-3000"
            style={{
              background: 'conic-gradient(red 0deg 180deg, black 180deg 360deg)',
              transform: `rotate(${wheelRotation}deg)`,
            }}
          >
            <div className="w-12 h-12 bg-[#D4AF37] rounded-full flex items-center justify-center text-black font-bold">
              VS
            </div>
          </div>
        </div>
      </div>

      {/* Result Display */}
      {result && (
        <div className="text-center">
          <p className="text-gray-400 text-sm mb-2">Resultado</p>
          <div className={`text-4xl font-bold ${result === 'red' ? 'text-red-500' : 'text-gray-300'}`}>
            {result === 'red' ? '🔴 VERMELHO' : '⚫ PRETO'}
          </div>
          <p className={`text-lg font-semibold mt-2 ${message.includes('ganhou') ? 'text-green-400' : 'text-red-400'}`}>
            {message}
          </p>
        </div>
      )}

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={isSpinning}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={isSpinning}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Color Selection */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-3">Escolha uma cor</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setSelectedColor('red')}
            disabled={isSpinning}
            className={`py-4 rounded-lg font-semibold transition-all ${
              selectedColor === 'red'
                ? 'bg-red-600 border-2 border-red-400 scale-105'
                : 'bg-red-900/30 border-2 border-red-600 hover:bg-red-900/50'
            }`}
          >
            🔴 Vermelho
          </button>
          <button
            onClick={() => setSelectedColor('black')}
            disabled={isSpinning}
            className={`py-4 rounded-lg font-semibold transition-all ${
              selectedColor === 'black'
                ? 'bg-gray-700 border-2 border-gray-400 scale-105'
                : 'bg-gray-900/30 border-2 border-gray-600 hover:bg-gray-900/50'
            }`}
          >
            ⚫ Preto
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={spinWheel}
          disabled={!selectedColor || isSpinning}
          className="btn-premium flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <Play className="w-5 h-5" />
          <span>{isSpinning ? 'Girando...' : 'Girar'}</span>
        </button>
        <button
          onClick={resetGame}
          className="px-4 py-3 rounded-lg font-semibold border border-[#2A3A52] text-gray-300 hover:bg-[#1E2847] transition-colors"
        >
          <RotateCcw className="w-5 h-5 inline mr-2" />
          Reiniciar
        </button>
      </div>

      {/* Last Results */}
      <div>
        <h3 className="text-sm font-semibold text-gray-300 mb-3">Últimos Resultados</h3>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {gameHistory.map((result, i) => (
            <div
              key={i}
              className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg ${
                result === 'red'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-700 text-white'
              }`}
            >
              {result === 'red' ? '🔴' : '⚫'}
            </div>
          ))}
        </div>
      </div>

      {/* Balance Info */}
      <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
        <p className="text-sm text-gray-300">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>
    </div>
  );
}
