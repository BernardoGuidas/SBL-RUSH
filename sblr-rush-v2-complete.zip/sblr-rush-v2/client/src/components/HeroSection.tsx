import { ArrowRight, Zap } from 'lucide-react';

interface HeroSectionProps {
  onGetStarted: () => void;
  onLearnMore: () => void;
}

export default function HeroSection({ onGetStarted, onLearnMore }: HeroSectionProps) {
  return (
    <section className="pt-32 pb-20 px-4 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-[#0F3A7D] rounded-full mix-blend-multiply filter blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#D4AF37] rounded-full mix-blend-multiply filter blur-3xl"></div>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-[#1E2847] px-4 py-2 rounded-full border border-[#D4AF37]/30">
                <Zap className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm text-[#D4AF37] font-semibold">Plataforma Premium de Apostas</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl font-bold text-white leading-tight">
                Aposte e <span className="text-[#D4AF37]">multiplique</span> seu dinheiro
              </h1>
              
              <p className="text-xl text-gray-400 leading-relaxed">
                Jogue os melhores mini-jogos de cassino online com interface premium. Ganhos em tempo real, segurança garantida e experiência incomparável.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onGetStarted}
                className="btn-premium flex items-center justify-center space-x-2 group"
              >
                <span>Comece Agora</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={onLearnMore}
                className="px-6 py-3 rounded-lg font-semibold border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10 transition-all"
              >
                Saiba Mais
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-[#2A3A52]">
              <div>
                <p className="text-3xl font-bold text-[#D4AF37]">50K+</p>
                <p className="text-sm text-gray-400">Jogadores Ativos</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#D4AF37]">1000x</p>
                <p className="text-sm text-gray-400">Multiplicador Máximo</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-[#D4AF37]">24/7</p>
                <p className="text-sm text-gray-400">Suporte Ativo</p>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative h-96 md:h-full">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-1_1770597625000_na1fn_aGVyby1iYW5uZXI.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTFfMTc3MDU5NzYyNTAwMF9uYTFmbl9hR1Z5YnkxaVlXNXVaWEkucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=g1-75VjZROpjIzQxb6UgTXGIdKkY1zzG89GJ-8ZWm-mQGmN5bzgJnDsTcrf7ngnnXZ7piB4J2WlYtQUvmPRJagAAKFv-E6ARpXNm2g32qNOyl1yZ7PeG9vhXzUHZNnNYErMYqVZgCnf7IZeXMiV~yw3RVhkJGGQy-Ye8zzAVo1rI82RcIuZhCBfoENa~y6INsPiGcW3uxwM9mGXa9KNZiITEEFQi5g8EOAHIDQYR3BsIT2JGFepsHACCdUeakNubP5lPt1jVpNiUsBNP-fFSVqNjx2rOxu~neJOW-bVMkV97joDKU3l~NlIzZHy1sPtEpiSNef820f0k2mU7l2wu3g__"
              alt="Hero Banner"
              className="w-full h-full object-cover rounded-xl border border-[#2A3A52]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E27] via-transparent to-transparent rounded-xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
