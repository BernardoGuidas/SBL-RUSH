import { useState, useEffect } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface CrashGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

export default function CrashGame({ onClose, onBalanceUpdate, currentBalance = 1000 }: CrashGameProps) {
  const [multiplier, setMultiplier] = useState(1.0);
  const [isRunning, setIsRunning] = useState(false);
  const [crashed, setCrashed] = useState(false);
  const [crashPoint, setCrashPoint] = useState(0);
  const [betAmount, setBetAmount] = useState(10);
  const [cashoutMultiplier, setCashoutMultiplier] = useState(1.0);
  const [gameHistory, setGameHistory] = useState<number[]>([3.24, 5.12, 1.89, 8.45, 2.56]);
  const [balance, setBalance] = useState(currentBalance);
  const [gameResult, setGameResult] = useState<{ won: boolean; amount: number } | null>(null);

  useEffect(() => {
    setBalance(currentBalance);
  }, [currentBalance]);

  useEffect(() => {
    if (!isRunning) return;

    const crashAt = Math.random() * 10 + 1.2;
    setCrashPoint(crashAt);
    let currentMultiplier = 1.0;

    const interval = setInterval(() => {
      currentMultiplier += Math.random() * 0.15;

      if (currentMultiplier >= crashAt) {
        setMultiplier(crashAt);
        setCrashed(true);
        setIsRunning(false);
        setGameHistory([crashAt, ...gameHistory.slice(0, 4)]);
        setGameResult({ won: false, amount: 0 });
        clearInterval(interval);
        return;
      }

      setMultiplier(parseFloat(currentMultiplier.toFixed(2)));
    }, 100);

    return () => clearInterval(interval);
  }, [isRunning, gameHistory]);

  const startGame = () => {
    if (betAmount > balance) {
      alert('Saldo insuficiente!');
      return;
    }

    const newBalance = balance - betAmount;
    setBalance(newBalance);
    if (onBalanceUpdate) {
      onBalanceUpdate(newBalance);
    }

    setMultiplier(1.0);
    setCrashed(false);
    setIsRunning(true);
    setCashoutMultiplier(1.0);
    setGameResult(null);
  };

  const cashout = () => {
    const winAmount = betAmount * multiplier;
    const newBalance = balance + winAmount;
    
    setBalance(newBalance);
    if (onBalanceUpdate) {
      onBalanceUpdate(newBalance);
    }

    setCashoutMultiplier(multiplier);
    setIsRunning(false);
    setGameResult({ won: true, amount: winAmount });
  };

  return (
    <div className="space-y-6">
      {/* Saldo Atual */}
      <div className="bg-[#1E2847] border border-[#2A3A52] rounded-lg p-4 text-center">
        <p className="text-gray-400 text-sm">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>

      {/* Game Chart */}
      <div className="bg-gradient-to-b from-[#1E2847] to-[#151B35] rounded-lg p-6 border border-[#2A3A52] min-h-64">
        <div className="flex items-end justify-between h-48 gap-1 mb-4">
          {/* Chart bars */}
          {[...Array(20)].map((_, i) => {
            const height = Math.sin(i * 0.5) * 40 + 50;
            return (
              <div
                key={i}
                className="flex-1 bg-gradient-to-t from-[#0F3A7D] to-[#D4AF37] rounded-t opacity-60"
                style={{ height: `${height}%` }}
              ></div>
            );
          })}
        </div>

        {/* Multiplier Display */}
        <div className="text-center">
          <p className="text-gray-400 text-sm mb-2">Multiplicador Atual</p>
          <div className={`text-5xl font-bold transition-all ${crashed ? 'text-red-500' : 'text-[#D4AF37]'}`}>
            {multiplier.toFixed(2)}x
          </div>
          {crashed && (
            <p className="text-red-500 font-semibold mt-2">💥 CRASHOU!</p>
          )}
        </div>
      </div>

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={isRunning}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={isRunning}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        {!isRunning ? (
          <button
            onClick={startGame}
            disabled={betAmount > balance}
            className="btn-premium flex items-center justify-center space-x-2 col-span-2 disabled:opacity-50"
          >
            <Play className="w-5 h-5" />
            <span>Iniciar Jogo</span>
          </button>
        ) : (
          <>
            <button
              onClick={cashout}
              className="btn-premium flex items-center justify-center space-x-2"
            >
              <span>Sacar</span>
              <span className="text-[#D4AF37] font-bold">{multiplier.toFixed(2)}x</span>
            </button>
            <button
              onClick={() => setIsRunning(false)}
              className="px-4 py-3 rounded-lg font-semibold border border-red-500 text-red-500 hover:bg-red-500/10 transition-colors"
            >
              Parar
            </button>
          </>
        )}
      </div>

      {/* Last Results */}
      <div>
        <h3 className="text-sm font-semibold text-gray-300 mb-3">Últimos Resultados</h3>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {gameHistory.map((result, i) => (
            <div
              key={i}
              className="flex-shrink-0 px-3 py-2 bg-[#1E2847] rounded-lg border border-[#2A3A52] text-center"
            >
              <p className="text-[#D4AF37] font-bold">{result.toFixed(2)}x</p>
            </div>
          ))}
        </div>
      </div>

      {/* Game Result */}
      {gameResult && (
        <div className={`rounded-lg p-4 border ${gameResult.won ? 'bg-[#1E5BA8]/20 border-[#1E5BA8]' : 'bg-red-500/20 border-red-500'}`}>
          <p className={`text-sm ${gameResult.won ? 'text-[#1E5BA8]' : 'text-red-500'}`}>
            {gameResult.won ? 'Você Ganhou! 🎉' : 'Você Perdeu! 😢'}
          </p>
          <p className={`text-lg font-bold ${gameResult.won ? 'text-[#D4AF37]' : 'text-red-500'} mt-1`}>
            {gameResult.won ? `+R$ ${gameResult.amount.toFixed(2)}` : `-R$ ${betAmount.toFixed(2)}`}
          </p>
        </div>
      )}

      {/* Info */}
      {cashoutMultiplier > 1 && !gameResult && (
        <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
          <p className="text-sm text-gray-300">
            Você sacou em <span className="text-[#D4AF37] font-bold">{cashoutMultiplier.toFixed(2)}x</span>
          </p>
          <p className="text-lg font-bold text-[#D4AF37] mt-1">
            Ganho: R$ {(betAmount * cashoutMultiplier).toFixed(2)}
          </p>
        </div>
      )}
    </div>
  );
}
