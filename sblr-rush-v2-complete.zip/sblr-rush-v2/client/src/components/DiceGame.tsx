import { useState } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface DiceGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

export default function DiceGame({ onClose }: DiceGameProps) {
  const [betAmount, setBetAmount] = useState(10);
  const [prediction, setPrediction] = useState<'high' | 'low' | 'even' | 'odd' | null>(null);
  const [isRolling, setIsRolling] = useState(false);
  const [dice1, setDice1] = useState(1);
  const [dice2, setDice2] = useState(1);
  const [result, setResult] = useState<string>('');
  const [gameHistory, setGameHistory] = useState<number[]>([7, 11, 4, 9, 6]);
  const [balance, setBalance] = useState(1000);
  const [message, setMessage] = useState('');

  const rollDice = () => {
    if (!prediction || isRolling) return;

    setIsRolling(true);
    setMessage('');
    setResult('');

    // Simulate rolling animation
    let rolls = 0;
    const rollInterval = setInterval(() => {
      setDice1(Math.floor(Math.random() * 6) + 1);
      setDice2(Math.floor(Math.random() * 6) + 1);
      rolls++;

      if (rolls > 15) {
        clearInterval(rollInterval);

        const finalDice1 = Math.floor(Math.random() * 6) + 1;
        const finalDice2 = Math.floor(Math.random() * 6) + 1;
        const total = finalDice1 + finalDice2;

        setDice1(finalDice1);
        setDice2(finalDice2);
        setResult(`Total: ${total}`);

        // Check if won
        let won = false;
        if (prediction === 'high' && total > 7) won = true;
        if (prediction === 'low' && total < 7) won = true;
        if (prediction === 'even' && total % 2 === 0) won = true;
        if (prediction === 'odd' && total % 2 !== 0) won = true;

        setIsRolling(false);

        if (won) {
          const winAmount = betAmount * 2;
          setBalance(balance + betAmount);
          setMessage(`✅ Você ganhou R$ ${winAmount.toFixed(2)}!`);
        } else {
          setBalance(balance - betAmount);
          setMessage(`❌ Você perdeu R$ ${betAmount.toFixed(2)}`);
        }

        setGameHistory([total, ...gameHistory.slice(0, 4)]);
      }
    }, 50);
  };

  const resetGame = () => {
    setPrediction(null);
    setResult('');
    setMessage('');
    setDice1(1);
    setDice2(1);
  };

  const getDiceEmoji = (num: number) => {
    const emojis = ['⚫', '⚪', '⚪⚪', '⚪⚪⚪', '⚪⚪⚪⚪', '⚪⚪⚪⚪⚪'];
    return emojis[num - 1];
  };

  return (
    <div className="space-y-6">
      {/* Dice Display */}
      <div className="flex justify-center gap-8 py-8">
        <div className="w-24 h-24 bg-gradient-to-br from-white to-gray-200 rounded-lg flex items-center justify-center text-4xl font-bold text-black border-4 border-[#D4AF37] transform transition-transform" style={{ transform: isRolling ? 'rotateY(360deg)' : 'rotateY(0deg)' }}>
          {dice1}
        </div>
        <div className="w-24 h-24 bg-gradient-to-br from-white to-gray-200 rounded-lg flex items-center justify-center text-4xl font-bold text-black border-4 border-[#D4AF37] transform transition-transform" style={{ transform: isRolling ? 'rotateY(-360deg)' : 'rotateY(0deg)' }}>
          {dice2}
        </div>
      </div>

      {/* Result Display */}
      {result && (
        <div className="text-center">
          <p className="text-gray-400 text-sm mb-2">Resultado</p>
          <div className="text-4xl font-bold text-[#D4AF37]">{result}</div>
          <p className={`text-lg font-semibold mt-2 ${message.includes('ganhou') ? 'text-green-400' : 'text-red-400'}`}>
            {message}
          </p>
        </div>
      )}

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={isRolling}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={isRolling}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Prediction Selection */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-3">Escolha sua previsão</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setPrediction('high')}
            disabled={isRolling}
            className={`py-3 rounded-lg font-semibold transition-all ${
              prediction === 'high'
                ? 'bg-green-600 border-2 border-green-400 scale-105'
                : 'bg-green-900/30 border-2 border-green-600 hover:bg-green-900/50'
            }`}
          >
            📈 Alto (&gt;7)
          </button>
          <button
            onClick={() => setPrediction('low')}
            disabled={isRolling}
            className={`py-3 rounded-lg font-semibold transition-all ${
              prediction === 'low'
                ? 'bg-blue-600 border-2 border-blue-400 scale-105'
                : 'bg-blue-900/30 border-2 border-blue-600 hover:bg-blue-900/50'
            }`}
          >
            📉 Baixo (&lt;7)
          </button>
          <button
            onClick={() => setPrediction('even')}
            disabled={isRolling}
            className={`py-3 rounded-lg font-semibold transition-all ${
              prediction === 'even'
                ? 'bg-purple-600 border-2 border-purple-400 scale-105'
                : 'bg-purple-900/30 border-2 border-purple-600 hover:bg-purple-900/50'
            }`}
          >
            🔢 Par
          </button>
          <button
            onClick={() => setPrediction('odd')}
            disabled={isRolling}
            className={`py-3 rounded-lg font-semibold transition-all ${
              prediction === 'odd'
                ? 'bg-orange-600 border-2 border-orange-400 scale-105'
                : 'bg-orange-900/30 border-2 border-orange-600 hover:bg-orange-900/50'
            }`}
          >
            🎲 Ímpar
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={rollDice}
          disabled={!prediction || isRolling}
          className="btn-premium flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <Play className="w-5 h-5" />
          <span>{isRolling ? 'Rolando...' : 'Rolar'}</span>
        </button>
        <button
          onClick={resetGame}
          className="px-4 py-3 rounded-lg font-semibold border border-[#2A3A52] text-gray-300 hover:bg-[#1E2847] transition-colors"
        >
          <RotateCcw className="w-5 h-5 inline mr-2" />
          Reiniciar
        </button>
      </div>

      {/* Last Results */}
      <div>
        <h3 className="text-sm font-semibold text-gray-300 mb-3">Últimos Resultados</h3>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {gameHistory.map((result, i) => (
            <div
              key={i}
              className="flex-shrink-0 px-4 py-2 bg-[#1E2847] rounded-lg border border-[#2A3A52] text-center"
            >
              <p className="text-[#D4AF37] font-bold">{result}</p>
              <p className="text-xs text-gray-400">{result % 2 === 0 ? 'Par' : 'Ímpar'}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Balance Info */}
      <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
        <p className="text-sm text-gray-300">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>
    </div>
  );
}
