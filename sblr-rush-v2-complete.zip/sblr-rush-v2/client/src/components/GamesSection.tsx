import { Zap } from 'lucide-react';
import GameCard from './GameCard';

interface GamesSectionProps {
  onPlayCrash: () => void;
  onPlayMines: () => void;
  onPlayDouble: () => void;
  onPlayDice: () => void;
  onPlayPlinko: () => void;
  onPlayTowers: () => void;
}

export default function GamesSection({
  onPlayCrash,
  onPlayMines,
  onPlayDouble,
  onPlayDice,
  onPlayPlinko,
  onPlayTowers,
}: GamesSectionProps) {
  const crashImg = 'https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-2_1770597620000_na1fn_Z2FtZS1jcmFzaC12aXN1YWw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTJfMTc3MDU5NzYyMDAwMF9uYTFmbl9aMkZ0WlMxamNtRnphQzEyYVhOMVlXdy5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=FCdsmW3dgUQIKZyVWCoG5w3NjdsP8jiRwtZOdwdmxL5LpNRChdpf5lwKDhZKKsGAxKqEqRGjW8v9ZHo2VNhV7-OhHKwRQcEmaCbhq8NqPWIu8EPRG5zyVcZozaWYl4okEaB--~mPZ28IkygfnKjHqcJNVQ1ePG2-gmKKlOxnc~15Bh53mSjFCW3Wg30THvCqhxyz2PO8HLSoB-1PJwyDbq7Jn0MQn~uxGkHEerx8dafTL2DZJbxdErRTlzeqWekwJTJky18X82zLWYWbfHs74u~4fKRxU~5p45LcrrbCdY3VP56aiEP02weu4nlaN-Nv3TwYYXvZaK~nsJkNdwAcCg__';
  const minesImg = 'https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-3_1770597622000_na1fn_bW9uZXMtZ2FtZS12aXN1YWw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTNfMTc3MDU5NzYyMjAwMF9uYTFmbl9iV2x1WlhNdFoyRnRaUzEyYVhOMVlXdy5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=Rw2adTUJYyvzw3RNt8p-qt0u25AUBiGJql0wQghiyA9spUpLDSqCRUE~Jm~RJNEdcN2wJFTGlsOg5AHv2~tceXZCWvxKNBEu1GByJh-YFegLMYTz5AsQkhQni7c5nB02vy9i~zUpHmMjS1ufIuTdLL~jff5l~22re8Vn-JsurGtGZC2rjZ6kewzC4gWntRJlKop011sDAtqQGmZuRCBXPHBbyuFU1hYuj80a8QdzXmnFwR-b8bpMoShxRJNR6X~FPNo26LcqeLvvCiehe6VO6Ly8nevCmcSTfdmAjQvTctu1bzA0SUMmVXTy7l8UWvUTak2v1yZaf4vFIVcSDwt8Zw__';
  const doubleImg = 'https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-4_1770597620000_na1fn_d2FsbGV0LWlsbHVzdHJhdGlvbg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTRfMTc3MDU5NzYyMDAwMF9uYTFmbl9kMkZzYkdWMExXbHNiSFZ6ZEhKaGRHbHZiZy5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=jOKq9VVfueqHKUmj9k-5NQcohRQDEdm3snDE9kDvBRdCjlr5ddlRfVkiKCjd3u5ebhwPuesSh1OHxqS9Ym2KSXtZsVpMtYiSL7FdekcAPPqwmQXUEaQv-br~lEPYyN6iEfSowHO219BogSXHJn-UugcocdVxQJBJ59qL9YnZCyjpi5IYZ2TftdwABx4o-zFGvsWeYPSP~7vJt4O607SkGXXvP5jbv8nUtCOJ~g-NIOzSA7iWqsaJdjSuiSvX4YoCi2BiW82l1BIVmIz0Z-UeewNoCr30Bd~M~DIR4UsWkOM82BiQ6qYUkWd7dhtfXcO5fccJ3AHoVLmIgIuTezKK-Q__';
  const patternImg = 'https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-5_1770597622000_na1fn_cGF0dGVybi1iYWNrZ3JvdW5k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTVfMTc3MDU5NzYyMjAwMF9uYTFmbl9jR0YwZEdWeWJpMWlZV05yWjNKdmRXNWsucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=oFEyDtWmGN16cgIXdaPptOABEiTPMAdFlexd~1fBYp2~572s6Sny~3MJzXM1v-aql~yDCQ7vm~hLjFTJNwqgQzaqqUeMWV5HtVg93eyEcg4k~3oiXwU05wuWRFNgGpdZt4IuUL9S2HIw5ifWvAWMQEuURJYq0rHGI4Vw9-b3VqTvoRTm0GyheSbboMV8~OCi91grw5Rvxhppz6ze09z~6OR9SS1LO9xVTixJk--Wr2MrPiK46ZrVoXE-u676FsX92Iy0Hc82lv~nhQt1EOp3LyvxttD4328zrn9XoZklUg3RCtUkSX~YgZXw04UpHrMksG~XuOYGigrRa8yCUuICyw__';
  const heroImg = 'https://private-us-east-1.manuscdn.com/sessionFile/gEEAvyk4umab2CTXZGgAn3/sandbox/H8KOQQ0gqDE5fHU5fX5Swh-img-1_1770597625000_na1fn_aGVyby1iYW5uZXI.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvZ0VFQXZ5azR1bWFiMkNUWFpHZ0FuMy9zYW5kYm94L0g4S09RUTBncURFNWZIVTVmWDVTd2gtaW1nLTFfMTc3MDU5NzYyNTAwMF9uYTFmbl9hR1Z5YnkxaVlXNXVaWEkucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=g1-75VjZROpjIzQxb6UgTXGIdKkY1zzG89GJ-8ZWm-mQGmN5bzgJnDsTcrf7ngnnXZ7piB4J2WlYtQUvmPRJagAAKFv-E6ARpXNm2g32qNOyl1yZ7PeG9vhXzUHZNnNYErMYqVZgCnf7IZeXMiV~yw3RVhkJGGQy-Ye8zzAVo1rI82RcIuZhCBfoENa~y6INsPiGcW3uxwM9mGXa9KNZiITEEFQi5g8EOAHIDQYR3BsIT2JGFepsHACCdUeakNubP5lPt1jVpNiUsBNP-fFSVqNjx2rOxu~neJOW-bVMkV97joDKU3l~NlIzZHy1sPtEpiSNef820f0k2mU7l2wu3g__';

  const games = [
    {
      title: 'Crash',
      description: 'Voe alto e saia no momento certo antes do crash!',
      icon: '🚀',
      image: crashImg,
      players: 2543,
      multiplier: 'até 1000x',
      onPlay: onPlayCrash,
    },
    {
      title: 'Mines',
      description: 'Encontre as gemas e evite as minas explosivas!',
      icon: '💎',
      image: minesImg,
      players: 1876,
      multiplier: 'até 500x',
      onPlay: onPlayMines,
    },
    {
      title: 'Double',
      description: 'Escolha vermelho ou preto e dobre seu dinheiro!',
      icon: '🎰',
      image: doubleImg,
      players: 3421,
      multiplier: '2x',
      onPlay: onPlayDouble,
    },
    {
      title: 'Dice',
      description: 'Role os dados e vença com a combinação certa!',
      icon: '🎲',
      image: patternImg,
      players: 1234,
      multiplier: 'até 6x',
      onPlay: onPlayDice,
    },
    {
      title: 'Plinko',
      description: 'Deixe a bola cair e ganhe prêmios incríveis!',
      icon: '⚪',
      image: heroImg,
      players: 2156,
      multiplier: 'até 100x',
      onPlay: onPlayPlinko,
    },
    {
      title: 'Torres',
      description: 'Encontre as gemas em 3 torres diferentes!',
      icon: '🏰',
      image: patternImg,
      players: 1567,
      multiplier: 'até 50x',
      onPlay: onPlayTowers,
    },
  ];

  return (
    <section id="games" className="py-20 px-4">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="mb-12 text-center">
          <div className="inline-flex items-center space-x-2 bg-[#1E2847] px-4 py-2 rounded-full border border-[#D4AF37]/30 mb-4">
            <Zap className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-[#D4AF37] font-semibold">Jogos Disponíveis</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Escolha seu <span className="text-[#D4AF37]">jogo favorito</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Seis mini-jogos incríveis com diferentes mecânicas e multiplicadores. Todos com interface premium e experiência suave.
          </p>
        </div>

        {/* Games Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game, index) => (
            <GameCard
              key={index}
              title={game.title}
              description={game.description}
              icon={game.icon}
              image={game.image}
              players={game.players}
              multiplier={game.multiplier}
              onPlay={game.onPlay}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
