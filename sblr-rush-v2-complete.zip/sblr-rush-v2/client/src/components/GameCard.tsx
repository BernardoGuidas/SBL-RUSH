import { Play, Users } from 'lucide-react';

interface GameCardProps {
  title: string;
  description: string;
  icon: string;
  image: string;
  players: number;
  multiplier: string;
  onPlay: () => void;
  isLive?: boolean;
}

export default function GameCard({
  title,
  description,
  icon,
  image,
  players,
  multiplier,
  onPlay,
  isLive = true,
}: GameCardProps) {
  return (
    <div className="card-premium group cursor-pointer overflow-hidden">
      {/* Image Container */}
      <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E27] via-transparent to-transparent"></div>

        {/* Live Badge */}
        {isLive && (
          <div className="absolute top-3 right-3 flex items-center space-x-2 bg-red-600 px-3 py-1 rounded-full">
            <div className="w-2 h-2 bg-white rounded-full live-badge"></div>
            <span className="text-xs font-semibold text-white">AO VIVO</span>
          </div>
        )}

        {/* Icon Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-16 h-16 rounded-full bg-[#D4AF37] flex items-center justify-center text-3xl">
            {icon}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-3">
        <div>
          <h3 className="text-xl font-bold text-white mb-1">{title}</h3>
          <p className="text-sm text-gray-400">{description}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 py-3 border-y border-[#2A3A52]">
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-gray-300">{players.toLocaleString()} jogadores</span>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Multiplicador</p>
            <p className="text-lg font-bold text-[#D4AF37]">{multiplier}</p>
          </div>
        </div>

        {/* Play Button */}
        <button
          onClick={onPlay}
          className="w-full btn-premium flex items-center justify-center space-x-2 group/btn"
        >
          <Play className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
          <span>Jogar Agora</span>
        </button>
      </div>
    </div>
  );
}
