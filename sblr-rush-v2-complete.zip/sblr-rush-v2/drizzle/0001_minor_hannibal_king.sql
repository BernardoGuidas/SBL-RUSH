CREATE TABLE `bets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` enum('crash','mines','double','dice','plinko','towers') NOT NULL,
	`betAmount` decimal(15,2) NOT NULL,
	`multiplier` decimal(10,2) NOT NULL,
	`winAmount` decimal(15,2) NOT NULL,
	`result` enum('win','loss') NOT NULL,
	`gameData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userFiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileKey` varchar(255) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(100) NOT NULL,
	`fileSize` int NOT NULL,
	`fileType` enum('profileImage','document','other') NOT NULL DEFAULT 'other',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userFiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `userFiles_fileKey_unique` UNIQUE(`fileKey`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(15,2) DEFAULT '100.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `profileImageUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWinnings` decimal(15,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalLosses` decimal(15,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `gamesPlayed` int DEFAULT 0 NOT NULL;