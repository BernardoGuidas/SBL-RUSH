import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createBet, getUserBets, updateUserBalance, createUserFile, getUserFiles } from "./db";
import { storagePut, storageGet } from "./storage";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  games: router({
    createBet: protectedProcedure
      .input(z.object({
        gameType: z.enum(["crash", "mines", "double", "dice", "plinko", "towers"]),
        betAmount: z.string(),
        multiplier: z.string(),
        winAmount: z.string(),
        result: z.enum(["win", "loss"]),
        gameData: z.any().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return await createBet({
          userId: ctx.user.id,
          gameType: input.gameType,
          betAmount: input.betAmount as any,
          multiplier: input.multiplier as any,
          winAmount: input.winAmount as any,
          result: input.result,
          gameData: input.gameData,
        });
      }),

    getBetsHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return await getUserBets(ctx.user.id, input.limit);
      }),

    updateBalance: protectedProcedure
      .input(z.object({ newBalance: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await updateUserBalance(ctx.user.id, input.newBalance);
        return { success: true };
      }),
  }),

  storage: router({
    uploadProfileImage: protectedProcedure
      .input(z.object({
        fileData: z.string(),
        fileName: z.string(),
        mimeType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const fileKey = `users/${ctx.user.id}/profile/${nanoid()}-${input.fileName}`;
        const buffer = Buffer.from(input.fileData, 'base64');
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        await createUserFile({
          userId: ctx.user.id,
          fileKey,
          fileUrl: url,
          fileName: input.fileName,
          mimeType: input.mimeType,
          fileSize: buffer.length,
          fileType: "profileImage",
        });
        
        return { url, fileKey };
      }),

    getUserFiles: protectedProcedure
      .query(async ({ ctx }) => {
        return await getUserFiles(ctx.user.id);
      }),

    getFileUrl: protectedProcedure
      .input(z.object({ fileKey: z.string() }))
      .query(async ({ input }) => {
        const { url } = await storageGet(input.fileKey);
        return { url };
      }),
  }),
});

export type AppRouter = typeof appRouter;
