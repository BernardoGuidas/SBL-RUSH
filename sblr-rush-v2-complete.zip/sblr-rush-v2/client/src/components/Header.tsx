import { useState } from 'react';
import { Menu, X, Wallet, LogOut } from 'lucide-react';

interface HeaderProps {
  balance: number;
  isLoggedIn: boolean;
  onDeposit: () => void;
  onWithdraw: () => void;
  onLogin: () => void;
  onLogout: () => void;
}

export default function Header({
  balance,
  isLoggedIn,
  onDeposit,
  onWithdraw,
  onLogin,
  onLogout,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full z-50 bg-gradient-to-b from-[#0F1B35] to-[#0A0E27] border-b border-[#2A3A52]">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0F3A7D] to-[#1E5BA8] flex items-center justify-center">
            <span className="text-xl font-bold text-white">🚀</span>
          </div>
          <span className="text-2xl font-bold text-[#D4AF37]">SBLRush</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#games" className="text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
            Jogos
          </a>
          <a href="#crash" className="text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
            Crash
          </a>
          <a href="#mines" className="text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
            Mines
          </a>
          <a href="#stats" className="text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
            Estatísticas
          </a>
        </nav>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Saldo Flutuante - Sempre Visível */}
          {isLoggedIn && (
            <div className="flex items-center space-x-3 bg-gradient-to-r from-[#D4AF37]/20 to-[#D4AF37]/10 px-5 py-3 rounded-lg border border-[#D4AF37]/50 backdrop-blur-sm">
              <Wallet className="w-5 h-5 text-[#D4AF37]" />
              <div className="flex flex-col">
                <span className="text-xs text-gray-300 font-medium">Saldo Total</span>
                <span className="text-xl font-bold text-[#D4AF37]">R$ {balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          )}

          {isLoggedIn ? (
            <>
              <button
                onClick={onDeposit}
                className="hidden md:block btn-premium"
              >
                Depositar
              </button>
              <button
                onClick={onWithdraw}
                className="hidden md:block btn-premium"
              >
                Sacar
              </button>
              <button
                onClick={onLogout}
                className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/30 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="hidden md:inline">Sair</span>
              </button>
            </>
          ) : (
            <button
              onClick={onLogin}
              className="btn-premium"
            >
              Entrar
            </button>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-[#D4AF37]"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#151B35] border-t border-[#2A3A52]">
          <nav className="container mx-auto px-4 py-4 space-y-4">
            <a href="#games" className="block text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
              Jogos
            </a>
            <a href="#crash" className="block text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
              Crash
            </a>
            <a href="#mines" className="block text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
              Mines
            </a>
            <a href="#stats" className="block text-gray-300 hover:text-[#D4AF37] transition-colors font-medium">
              Estatísticas
            </a>
            {isLoggedIn && (
              <div className="pt-4 border-t border-[#2A3A52] space-y-2">
                <button onClick={onDeposit} className="w-full btn-premium">
                  Depositar
                </button>
                <button onClick={onWithdraw} className="w-full btn-premium">
                  Sacar
                </button>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
