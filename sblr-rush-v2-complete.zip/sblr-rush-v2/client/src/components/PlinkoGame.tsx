import { useState } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface PlinkoGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

interface Ball {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  landed: boolean;
  finalBucket: number;
}

export default function PlinkoGame({ onClose }: PlinkoGameProps) {
  const [betAmount, setBetAmount] = useState(10);
  const [isDropping, setIsDropping] = useState(false);
  const [balls, setBalls] = useState<Ball[]>([]);
  const [buckets, setBuckets] = useState<number[]>([0, 0, 0, 0, 0, 0, 0, 0]);
  const [gameHistory, setGameHistory] = useState<number[]>([]);
  const [balance, setBalance] = useState(1000);
  const [message, setMessage] = useState('');
  const [ballCount, setBallCount] = useState(1);

  const bucketMultipliers = [0.5, 1, 2, 5, 10, 5, 2, 1];
  const pegRows = 8;
  const pegSpacing = 50;

  const dropBall = () => {
    if (isDropping) return;

    setIsDropping(true);
    setMessage('');

    const newBalls: Ball[] = [];
    for (let i = 0; i < ballCount; i++) {
      newBalls.push({
        id: Date.now() + i,
        x: 200 + Math.random() * 40 - 20,
        y: 20,
        vx: (Math.random() - 0.5) * 2,
        vy: 0,
        landed: false,
        finalBucket: 0,
      });
    }

    let currentBalls = newBalls;
    let animationFrames = 0;
    const maxFrames = 300;

    const animate = () => {
      currentBalls = currentBalls.map((ball: Ball) => {
        if (ball.landed) return ball;

        let { x, y, vx, vy } = ball;

        // Gravity
        vy += 0.3;

        // Collision with pegs
        for (let row = 0; row < pegRows; row++) {
          const pegY = 60 + row * pegSpacing;
          const pegsInRow = row + 1;

          for (let col = 0; col < pegsInRow; col++) {
            const pegX = 200 - (pegsInRow * pegSpacing) / 2 + col * pegSpacing;

            const dx = x - pegX;
            const dy = y - pegY;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 15) {
              const angle = Math.atan2(dy, dx);
              vx = Math.cos(angle) * 3;
              vy = Math.sin(angle) * 3;
            }
          }
        }

        // Boundaries
        if (x < 50) {
          x = 50;
          vx = Math.abs(vx);
        }
        if (x > 350) {
          x = 350;
          vx = -Math.abs(vx);
        }

        // Landing in bucket
        if (y > 400) {
          const bucketIndex = Math.floor((x - 50) / (300 / 8));
          return {
            ...ball,
            y: 400,
            vy: 0,
            vx: 0,
            landed: true,
            finalBucket: Math.max(0, Math.min(7, bucketIndex)),
          };
        }

        x += vx;
        y += vy;

        return { ...ball, x, y, vx, vy };
      });

      setBalls([...currentBalls]);

      animationFrames++;
      if (animationFrames < maxFrames) {
        requestAnimationFrame(animate);
      } else {
        // Calculate results
        const newBuckets = [...buckets];
        let totalWinnings = 0;

        currentBalls.forEach((ball: Ball) => {
          if (ball.landed) {
            newBuckets[ball.finalBucket]++;
            totalWinnings += betAmount * bucketMultipliers[ball.finalBucket];
          }
        });

        setBuckets(newBuckets);
        setBalance((prev) => prev + totalWinnings - betAmount * ballCount);
        setMessage(`Ganho: R$ ${totalWinnings.toFixed(2)}`);
        setGameHistory((prev) => [...prev, totalWinnings]);
        setIsDropping(false);
      }
    };

    animate();
  };

  const resetGame = () => {
    setBalls([]);
    setBuckets([0, 0, 0, 0, 0, 0, 0, 0]);
    setMessage('');
  };

  return (
    <div className="space-y-6">
      {/* Plinko Board */}
      <div className="bg-gradient-to-b from-[#1E2847] to-[#151B35] rounded-lg p-6 border border-[#2A3A52] overflow-hidden">
        <svg width="100%" height="450" viewBox="0 0 400 450" className="bg-gradient-to-b from-[#0F1B35] to-[#151B35]">
          {/* Pegs */}
          {Array.from({ length: pegRows }).map((_, row) => {
            const pegsInRow = row + 1;
            return Array.from({ length: pegsInRow }).map((_, col) => {
              const pegX = 200 - (pegsInRow * pegSpacing) / 2 + col * pegSpacing;
              const pegY = 60 + row * pegSpacing;
              return (
                <circle
                  key={`peg-${row}-${col}`}
                  cx={pegX}
                  cy={pegY}
                  r="8"
                  fill="#D4AF37"
                  opacity="0.8"
                />
              );
            });
          })}

          {/* Buckets */}
          {buckets.map((count, i) => {
            const bucketX = 50 + (i * 300) / 8;
            return (
              <g key={`bucket-${i}`}>
                <rect x={bucketX - 15} y="410" width="30" height="30" fill="#1E5BA8" stroke="#D4AF37" strokeWidth="2" />
                <text x={bucketX} y="435" textAnchor="middle" fill="#D4AF37" fontSize="12" fontWeight="bold">
                  {count}
                </text>
              </g>
            );
          })}

          {/* Balls */}
          {balls.map((ball) => (
            <circle
              key={`ball-${ball.id}`}
              cx={ball.x}
              cy={ball.y}
              r="6"
              fill="#D4AF37"
              opacity={ball.landed ? 0.5 : 1}
            />
          ))}

          {/* Multipliers */}
          {bucketMultipliers.map((mult, i) => {
            const bucketX = 50 + (i * 300) / 8;
            return (
              <text
                key={`mult-${i}`}
                x={bucketX}
                y="25"
                textAnchor="middle"
                fill="#D4AF37"
                fontSize="14"
                fontWeight="bold"
              >
                {mult}x
              </text>
            );
          })}
        </svg>
      </div>

      {/* Result Display */}
      {message && (
        <div className="text-center">
          <p className="text-gray-400 text-sm mb-2">Resultado</p>
          <p className="text-2xl font-bold text-[#D4AF37]">{message}</p>
        </div>
      )}

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={isDropping}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={isDropping}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Ball Count */}
      <div>
        <label className="block text-sm font-semibold text-gray-300 mb-2">Quantidade de Bolas</label>
        <div className="flex gap-2">
          {[1, 2, 3, 5].map((count) => (
            <button
              key={count}
              onClick={() => setBallCount(count)}
              disabled={isDropping}
              className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                ballCount === count
                  ? 'bg-[#D4AF37] text-black'
                  : 'bg-[#1E2847] text-gray-300 hover:bg-[#2A3A52]'
              }`}
            >
              {count}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={dropBall}
          disabled={isDropping}
          className="btn-premium flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <Play className="w-5 h-5" />
          <span>{isDropping ? 'Caindo...' : 'Soltar'}</span>
        </button>
        <button
          onClick={resetGame}
          className="px-4 py-3 rounded-lg font-semibold border border-[#2A3A52] text-gray-300 hover:bg-[#1E2847] transition-colors"
        >
          <RotateCcw className="w-5 h-5 inline mr-2" />
          Reiniciar
        </button>
      </div>

      {/* Last Results */}
      {gameHistory.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Últimos Ganhos</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {gameHistory.slice(-5).map((result, i) => (
              <div
                key={i}
                className="flex-shrink-0 px-3 py-2 bg-[#1E2847] rounded-lg border border-[#2A3A52] text-center"
              >
                <p className="text-[#D4AF37] font-bold">R$ {result.toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Balance Info */}
      <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
        <p className="text-sm text-gray-300">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>
    </div>
  );
}
