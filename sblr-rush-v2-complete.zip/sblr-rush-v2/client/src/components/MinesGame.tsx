import { useState, useEffect } from 'react';
import { Play, RotateCcw } from 'lucide-react';

interface MinesGameProps {
  onClose: () => void;
  onBalanceUpdate?: (newBalance: number) => void;
  currentBalance?: number;
}

export default function MinesGame({ onClose, onBalanceUpdate, currentBalance = 1000 }: MinesGameProps) {
  const [grid, setGrid] = useState<('hidden' | 'gem' | 'mine' | 'revealed-gem' | 'revealed-mine')[]>(
    Array(25).fill('hidden')
  );
  const [gameActive, setGameActive] = useState(false);
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [revealed, setRevealed] = useState<number[]>([]);
  const [multiplier, setMultiplier] = useState(1.0);
  const [betAmount, setBetAmount] = useState(10);
  const [gemsFound, setGemsFound] = useState(0);
  const [totalMines] = useState(5);
  const [balance, setBalance] = useState(currentBalance);
  const [gameResult, setGameResult] = useState<{ won: boolean; amount: number } | null>(null);

  useEffect(() => {
    setBalance(currentBalance);
  }, [currentBalance]);

  const startGame = () => {
    if (betAmount > balance) {
      alert('Saldo insuficiente!');
      return;
    }
    
    const newBalance = balance - betAmount;
    setBalance(newBalance);
    if (onBalanceUpdate) {
      onBalanceUpdate(newBalance);
    }
    
    const mines = new Set<number>();
    while (mines.size < totalMines) {
      mines.add(Math.floor(Math.random() * 25));
    }
    setMinePositions(Array.from(mines));
    setGrid(Array(25).fill('hidden'));
    setRevealed([]);
    setGemsFound(0);
    setMultiplier(1.0);
    setGameActive(true);
    setGameResult(null);
  };

  const revealCell = (index: number) => {
    if (!gameActive || revealed.includes(index)) return;

    const newRevealed = [...revealed, index];
    setRevealed(newRevealed);

    if (minePositions.includes(index)) {
      // Hit a mine - Game Over
      const newGrid = [...grid];
      minePositions.forEach((pos) => {
        newGrid[pos] = 'revealed-mine';
      });
      setGrid(newGrid);
      setGameActive(false);
      setGameResult({ won: false, amount: 0 });
      return;
    }

    // Found a gem
    const newGemsFound = gemsFound + 1;
    setGemsFound(newGemsFound);
    setMultiplier(1.0 + newGemsFound * 0.5);

    const newGrid = [...grid];
    newGrid[index] = 'revealed-gem';
    setGrid(newGrid);
  };

  const cashout = () => {
    const winAmount = betAmount * multiplier;
    const newBalance = balance + winAmount;
    
    setBalance(newBalance);
    if (onBalanceUpdate) {
      onBalanceUpdate(newBalance);
    }
    
    setGameActive(false);
    setGameResult({ won: true, amount: winAmount });
  };

  const resetGame = () => {
    setGrid(Array(25).fill('hidden'));
    setGameActive(false);
    setRevealed([]);
    setMinePositions([]);
    setGemsFound(0);
    setMultiplier(1.0);
  };

  return (
    <div className="space-y-6">
      {/* Saldo Atual */}
      <div className="bg-[#1E2847] border border-[#2A3A52] rounded-lg p-4 text-center">
        <p className="text-gray-400 text-sm">Saldo Atual</p>
        <p className="text-2xl font-bold text-[#D4AF37]">R$ {balance.toFixed(2)}</p>
      </div>

      {/* Game Grid */}
      <div className="bg-gradient-to-b from-[#1E2847] to-[#151B35] rounded-lg p-6 border border-[#2A3A52]">
        <div className="grid grid-cols-5 gap-2 mb-6">
          {grid.map((cell, index) => (
            <button
              key={index}
              onClick={() => revealCell(index)}
              disabled={!gameActive || revealed.includes(index)}
              className={`aspect-square rounded-lg font-bold text-lg transition-all ${
                cell === 'hidden'
                  ? 'bg-gradient-to-br from-[#2A3A52] to-[#1E2847] hover:from-[#3A4A62] border border-[#3A4A62]'
                  : cell === 'revealed-gem'
                    ? 'bg-gradient-to-br from-[#10b981] to-[#059669] border border-[#34d399]'
                    : 'bg-gradient-to-br from-[#dc2626] to-[#991b1b] border border-[#ef4444]'
              } ${!gameActive || revealed.includes(index) ? 'cursor-default' : 'cursor-pointer hover:scale-105'}`}
            >
              {cell === 'revealed-gem' && '💎'}
              {cell === 'revealed-mine' && '💣'}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-gray-400 text-sm">Gemas Encontradas</p>
            <p className="text-2xl font-bold text-[#D4AF37]">{gemsFound}</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Multiplicador</p>
            <p className="text-2xl font-bold text-[#D4AF37]">{multiplier.toFixed(2)}x</p>
          </div>
          <div>
            <p className="text-gray-400 text-sm">Ganho Potencial</p>
            <p className="text-2xl font-bold text-[#D4AF37]">R$ {(betAmount * multiplier).toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Bet Controls */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-300 mb-2">Valor da Aposta</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Math.max(1, Number(e.target.value)))}
              disabled={gameActive}
              className="flex-1 bg-[#1E2847] border border-[#2A3A52] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-[#D4AF37]"
            />
            <span className="px-4 py-2 bg-[#1E2847] rounded-lg text-[#D4AF37] font-semibold">R$</span>
          </div>
        </div>

        {/* Quick Bet Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {[10, 50, 100, 500].map((amount) => (
            <button
              key={amount}
              onClick={() => setBetAmount(amount)}
              disabled={gameActive}
              className="py-2 px-3 bg-[#1E2847] hover:bg-[#2A3A52] text-gray-300 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50"
            >
              R$ {amount}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        {!gameActive ? (
          <button
            onClick={startGame}
            disabled={betAmount > balance}
            className="btn-premium flex items-center justify-center space-x-2 col-span-2 disabled:opacity-50"
          >
            <Play className="w-5 h-5" />
            <span>Iniciar Jogo</span>
          </button>
        ) : (
          <button
            onClick={cashout}
            className="btn-premium flex items-center justify-center space-x-2 col-span-2"
          >
            <span>Sacar R$ {(betAmount * multiplier).toFixed(2)}</span>
          </button>
        )}
        <button
          onClick={resetGame}
          className="col-span-2 px-4 py-3 rounded-lg font-semibold border border-[#2A3A52] text-gray-300 hover:bg-[#1E2847] transition-colors"
        >
          <RotateCcw className="w-5 h-5 inline mr-2" />
          Reiniciar
        </button>
      </div>

      {/* Game Result */}
      {gameResult && (
        <div className={`rounded-lg p-4 border ${gameResult.won ? 'bg-[#1E5BA8]/20 border-[#1E5BA8]' : 'bg-red-500/20 border-red-500'}`}>
          <p className={`text-sm ${gameResult.won ? 'text-[#1E5BA8]' : 'text-red-500'}`}>
            {gameResult.won ? 'Você Ganhou! 🎉' : 'Você Perdeu! 😢'}
          </p>
          <p className={`text-lg font-bold ${gameResult.won ? 'text-[#D4AF37]' : 'text-red-500'} mt-1`}>
            {gameResult.won ? `+R$ ${gameResult.amount.toFixed(2)}` : `-R$ ${betAmount.toFixed(2)}`}
          </p>
        </div>
      )}

      {/* Info */}
      <div className="bg-[#1E5BA8]/20 border border-[#1E5BA8] rounded-lg p-4">
        <p className="text-sm text-gray-300">
          Encontre as gemas e evite as minas! Cada gema encontrada aumenta seu multiplicador.
        </p>
      </div>
    </div>
  );
}
